package com.cg.hbms.ui;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

import com.cg.hbms.dto.BookingDto;
import com.cg.hbms.dto.RoomDto;
import com.cg.hbms.exception.NoRoomsAvailableException;
import com.cg.hbms.service.AdminService;
import com.cg.hbms.service.AdminServiceImpl;
import com.cg.hbms.service.HotelEmployeeService;
import com.cg.hbms.service.HotelEmployeeServiceImpl;
import com.cg.hbms.service.Validation;
import com.cg.hbms.service.ValidationImpl;

public class Ui {

	static LocalDate  getDate()
	{

		Scanner sc=new Scanner(System.in);
		System.out.println("enter year");
		int year=sc.nextInt();
		System.out.println("enter month  from 1 to 12");
		int month=sc.nextInt();
		System.out.println("enter day ");
		int day =sc.nextInt();
		LocalDate ld=LocalDate.of(year, month, day);
		return ld;
	}
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String mainOption;
		char mainChoice='y';
		
		System.out.println("----------------WELCOME TO HBMS----------------");
		
		
		while(mainChoice=='y')
		{
			System.out.println("\n1. Login as Customer"
					+ "\n2. Login as Hotel Employee"
					+ "\n3. Login as Admin"
					+ "\n4. New user? Register"
					+ "\n5. Exit"
					+ "\n\nSelect option: ");
			mainOption=sc.nextLine();
			switch(mainOption)
			{
			case "1":
				System.out.println("User Login coming soon...");
				break;
				
				
			case "2":
				System.out.println("Hotel Employee Login ");
				int hotelId=101;
				int userId=1001;
			int heFlag = 1;
				
			    HotelEmployeeService he=new HotelEmployeeServiceImpl();
			    HashMap <Integer,RoomDto> roomHashMap=new HashMap<Integer,RoomDto>();
				int choice;
			    List<RoomDto>  roomList=null;
			    int roomChoice,roomTypeI;
			    String roomTypeS;
			    Double amount;
			    int numDays = 1 ;
			    boolean validToDateFlag = true,validFromDateFlag=true,tryAgainFlag=false,invalidLogin=true;
			    LocalDate fromDate;
				LocalDate toDate;
				String loginData;
				while(invalidLogin==true)
				{
				System.out.println("Enter user ID");
				String userIdString=sc.next();
				System.out.println("Enter Password");
				String password=sc.next();
				loginData=he.authenticateHotelEmployee(userIdString, password);
				if(loginData.equals("incorrectPassword"))
				{tryAgainFlag=true;
					System.out.println(loginData);
				}
				else if(loginData.equals("invalidUser"))
				{tryAgainFlag=true;
					System.out.println(loginData);

				}
				else
				{
					userId=Integer.parseInt(userIdString);
					hotelId=Integer.parseInt(loginData);
			 
			    do
			    {System.out.println("1.Display all the rooms \n 2.book a room \n 3.view booking transactions  ");
				 choice=sc.nextInt();
			    	
			 
				switch(choice)
				{
				
				case 1:
					roomHashMap=   he.displayRooms(hotelId, LocalDate.of(2020,3,13),  LocalDate.of(2020,3,14));
					Set<Entry<Integer,RoomDto>> entrySet=roomHashMap.entrySet();
					for(Entry entry : entrySet)
					{
						RoomDto room=new RoomDto();
						room=(RoomDto)entry.getValue();
						System.out.println(room.getRoomNo()+"       "+room.isAvailability()+"     "+room.getRoomType());
					}

					break;
				case 2:
					try
					{
				
					System.out.println("enter Type of the room\n1.AC\n2.NonAC");
					roomTypeI=sc.nextInt();
//					if(roomTypeI==1)
//					{
//						roomTypeS="AC";
//					}
//					else
//					{
//						roomTypeS="NAC";
//
//					}
					//validation for dates 
					/*
					 * 1.to date has to be after from date
					 * max days 1 week
					 * check for validity of the date ,ie date should not be before todays date
					 */
					/*
					 * if rooms available are all false,
					 * then exception has to be generated
					 * 
					 */
					/*
					 * booking details has to be updated in data base,
					 * so service layer and dao class must be written
					 */
					do
					{
						
						do
							{ 
							 if(validFromDateFlag==false)
								System.out.println("Invalid Date ");
							 else if(numDays==0)
									System.out.println("booking is allowed for only 7 days ");


					System.out.println("enter FROM date");
				 fromDate=getDate();
				 validFromDateFlag=he.validatefromDate(fromDate);
				 
							}while(validFromDateFlag==false);
				
					do {
					if(validToDateFlag==false)
						System.out.println("TO date has to be after FROM date");
					
					System.out.println("Enter TO date");
				        toDate=getDate();
				        numDays=he.validateNoOfDays(fromDate, toDate);
				        validToDateFlag=he.validateDate(fromDate, toDate);
					
					
					} while(validToDateFlag==false);
				
					}while(numDays==0 );
					 
				
					roomHashMap=   he.displayRoomsBasedOnType(hotelId, fromDate,toDate,roomTypeI);
					
					System.out.println("Rooms available are ::::::");
					Set<Entry<Integer,RoomDto>> entrySet1=roomHashMap.entrySet();
					
					for(Entry entry : entrySet1)
					{ 
						RoomDto room=new RoomDto();
						
						room=(RoomDto)entry.getValue();
						
						System.out.println(room.getRoomId()+"      "+room.getRoomNo()+"       "+room.isAvailability());
						
					}
					while(true)
					{
					System.out.println("Enter room Id");
					roomChoice=sc.nextInt();
				
					RoomDto tempRoom=roomHashMap.get(roomChoice);
					if(tempRoom==null)
					{
						System.out.println("invalid room number");
					}
					else
					{
					if(tempRoom.isAvailability()==true )
					{amount=tempRoom.getPerNightRate();
						break;
					}
					else
					{
						System.out.println("room is not available");
					}
					}
					}
					
					
					System.out.println("enter no of adults");
					int noOfAdult=sc.nextInt();
					
					System.out.println("enter no of children");
					int noOfChildren=sc.nextInt();
					
				amount=numDays*amount;
				System.out.println("Total    Amount"+amount);
					//		bookingData.put(9002,(new BookingDto(9002,1005,102,112,LocalDate.of(2020,2,20), LocalDate.of(2020,2,22),2,0,5000.0)));

			      BookingDto bookDto=new BookingDto(roomChoice,hotelId,userId,fromDate,toDate,noOfAdult,noOfChildren,amount);
			      String bookingStatus=he.addBookingRecord(bookDto);
						System.out.println(bookingStatus);
						System.out.println(bookDto);
						
				}
						catch(NoRoomsAvailableException e)
						{
							System.out.println(e);
						}
			
				default:
				       break;
				}
			    
				System.out.println("want to continue\n1.continue\n2.exit from Hotel Employee");
				heFlag=sc.nextInt();
			    }while(heFlag==1);
			    
				}
				
				if(tryAgainFlag==true)
				{
					System.out.println("would you like try again\n1.try again \n2.exit");
					if(sc.nextInt()==1)
						invalidLogin=true;
				}
				}
			    break;
				
				
			case "3":
				char adminLoginChoice='y';
				AdminService adminService= new AdminServiceImpl();
				Validation adminValidate=new ValidationImpl();
				while(adminLoginChoice=='y')
				{
					
					System.out.println("Enter Admin User ID: ");
					String strAdminId =sc.nextLine();
					System.out.println("Enter Admin password: ");
					String adminPassword=sc.nextLine();
					
					boolean isValidLoginCredentials = adminService.authenticate(strAdminId,adminPassword);
					if(isValidLoginCredentials)
					{
						System.out.println("Login Successful");
						String adminOption;
						char adminChoice='y';
						System.out.println("\n-----WELCOME ADMIN-----\nPlease select on option:\n");
						while(adminChoice=='y')
						{
							System.out.println("1. Add Hotel\n"
									+ "2. Delete Hotel\n"
									+ "3. Update Hotel\n"
									+ "4. Add Room\n"
									+ "5. Delete Room\n"
									+ "6. Update Room\n"
									+ "7. View List of Hotels\n"
									+ "8. View List of Customers\n"
									+ "9. View Bookings for a spcific hotel\n"
									+ "10. View Bookings of a specific date\n"
									+ "11. Back to Home Page\n"
									+ "12. Exit"
									+ "\nEnter choice (1-9) : ");
							adminOption = sc.nextLine();
							String strHotelId=null;
							String hotelName=null;
							String hotelCity=null;
							String hotelAddress=null;
							String hotelDescription=null;
							String strHotelAvgRatePerNight=null;
							String hotelPhone1=null;
							String hotelPhone2=null;
							String strHotelRating=null;
							String hotelEmail=null;
							String strRoomId=null;
							String roomType=null;
							String strPerNightRate=null;
							String roomNo=null;
							String strAvailability=null;
							String strDate=null;
							boolean isValidInput;
							switch(adminOption){
							case "1":
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Hotel Name : ");
									hotelName=sc.nextLine();
									isValidInput=adminValidate.isValidAlphanumericInput(hotelName);
									if(hotelName.length()>20 || !isValidInput)
									{
										System.out.println("Hotel Name can only contain alphabets, digits & spaces...(Max Length = 20)\n");
										isValidInput=false;
									}
								}
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter City : ");
									hotelCity=sc.nextLine();
									isValidInput=adminValidate.isValidAlphabeticInput(hotelCity);
									if(hotelCity.length()>10 || !isValidInput)
									{
										System.out.println("City Name can only contain alphabets...(Max Allowed Length = 10)\n");
										isValidInput=false;
									}
								}
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Hotel Address : ");
									hotelAddress=sc.nextLine();
									isValidInput=adminValidate.isValidAlphanumericInput(hotelAddress);
									if(hotelAddress.length()>25 || !isValidInput)
									{
										System.out.println("Hotel Address can only contain alphabets, Digits and spaces...(Max Allowed Length = 25)\n");
										isValidInput=false;
									}
								}
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Discription : ");
									hotelDescription=sc.nextLine();
									isValidInput=adminValidate.isValidAlphanumericInput(hotelDescription);
									if(hotelDescription.length()>50 || !isValidInput)
									{
										System.out.println("Descrition can only contain alphabtes, digits and spaces...(Max Allowed Length=50)\n");
										isValidInput=false;
									}
								}
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Average Rate per night : ");
									strHotelAvgRatePerNight=sc.nextLine();
									isValidInput=adminValidate.isValidAmount(strHotelAvgRatePerNight);
									if(!isValidInput)
									{
										System.out.println("Please Enter a Numerical value...\n");	
									}
								}
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Hotel Phone Number : ");
									hotelPhone1=sc.nextLine();
									isValidInput=adminValidate.isValidNumericInput(hotelPhone1);
									if(hotelPhone1.length()!=10 || !isValidInput)
									{
										System.out.println(isValidInput);
										System.out.println("Invalid Phone Number...\n");
										isValidInput=false;
									}
								}
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Alternate Phone Number : ");
									hotelPhone2=sc.nextLine();
									isValidInput=adminValidate.isValidNumericInput(hotelPhone2);
									if(hotelPhone1.length()!=10 || !isValidInput)
									{
										System.out.println(isValidInput);
										System.out.println("Invalid Phone Number...\n");
										isValidInput=false;
									}
								}
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Hotel Rating (out of 5): ");
									strHotelRating=sc.nextLine();
									isValidInput=adminValidate.isValidRating(strHotelRating);
									if(!isValidInput)
									{
										System.out.println("Please Enter a decimal value between 0 to 5...\n");
									}
								}
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Hotel Email ID : ");
									hotelEmail=sc.nextLine();
									isValidInput=adminValidate.isValidEmailId(hotelEmail);
									if(!isValidInput)
									{
										System.out.println("Invalid Email address...\n");
									}
								}
								System.out.println(adminService.addHotel(hotelName, hotelCity, hotelAddress, hotelDescription, strHotelAvgRatePerNight, hotelPhone1, hotelPhone2, strHotelRating, hotelEmail));
								break;
								
							case "2":
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Hotel ID : ");
									strHotelId = sc.nextLine();
									isValidInput=adminValidate.isValidNumericInput(strHotelId);
									if(strHotelId.length()!=3 || !isValidInput)
									{
										System.out.println("Hotel ID can only be numeric 3 digit value...\n");
										isValidInput=false;
									}
								}
								System.out.println(adminService.delHotel(strHotelId));
								sc.nextLine();
								break;
								
							case "3":
								String updateHotelOption;
								char updateHotelChoice='y';
								while(updateHotelChoice=='y')
								{
									isValidInput=false;
									while(!isValidInput)
									{
										System.out.println("Enter Hotel ID: ");
										strHotelId=sc.nextLine();
										isValidInput=adminValidate.isValidNumericInput(strHotelId);
										if(strHotelId.length()!=3 || !isValidInput)
										{
											System.out.println("Hotel ID can only be numeric 3 digit value...\n");
											isValidInput=false;
										}
									}
									System.out.println("\nSelect Field to update\n"
												+ "1. Update Hotel Address\n"
												+ "2. Update Hotel Description\n"
												+ "3. Update Hotel Tarrif\n"
												+ "4. Update Hotel Phone Number\n"
												+ "5. Update Hotel Email Address\n"
												+ "6. Go Back to Menu\n"
												+ "Select Option: ");
									updateHotelOption=sc.nextLine();
									switch(updateHotelOption)
									{
									case "1":
										isValidInput=false;
										while(!isValidInput)
										{
											System.out.println("Enter New Hotel Address : ");
											hotelAddress=sc.nextLine();
											isValidInput=adminValidate.isValidAlphanumericInput(hotelAddress);
											if(hotelAddress.length()>25 || !isValidInput)
											{
												System.out.println("Hotel Address can only contain alphabets, Digits and spaces...(Max Allowed Length = 25)\n");
												isValidInput=false;
											}
										}
										System.out.println(adminService.updateHotelAddress(strHotelId,hotelAddress));
										break;
									case "2":
										isValidInput=false;
										while(!isValidInput)
										{
											System.out.println("Enter New Discription : ");
											hotelDescription=sc.nextLine();
											isValidInput=adminValidate.isValidAlphanumericInput(hotelDescription);
											if(hotelDescription.length()>50 || !isValidInput)
											{
												System.out.println("Descrition can only contain alphabtes, digits and spaces...(Max Allowed Length=50)\n");
												isValidInput=false;
											}
										}
										System.out.println(adminService.updateHotelDescription(strHotelId,hotelDescription));
										
										break;
									case "3":
										isValidInput=false;
										while(!isValidInput)
										{
											System.out.println("Enter New Tarrif : ");
											strHotelAvgRatePerNight=sc.nextLine();
											isValidInput=adminValidate.isValidAmount(strHotelAvgRatePerNight);
											if(!isValidInput)
											{
												System.out.println("Please Enter a Numerical value...\n");	
											}
										}
										System.out.println(adminService.updateHotelAvgRatePerNight(strHotelId,strHotelAvgRatePerNight));
										
										break;
									case "4":
										isValidInput=false;
										while(!isValidInput)
										{
											System.out.println("Enter New Phone Number : ");
											hotelPhone1=sc.nextLine();
											isValidInput=adminValidate.isValidNumericInput(hotelPhone1);
											if(hotelPhone1.length()!=10 || !isValidInput)
											{
												System.out.println(isValidInput);
												System.out.println("Invalid Phone Number...\n");
												isValidInput=false;
											}
										}
										System.out.println(adminService.updateHotelPhone(strHotelId,hotelPhone1));
										
										break;
									case "5":
										isValidInput=false;
										while(!isValidInput)
										{
											System.out.println("Enter New Hotel Email ID : ");
											hotelEmail=sc.nextLine();
											isValidInput=adminValidate.isValidEmailId(hotelEmail);
											if(!isValidInput)
											{
												System.out.println("Invalid Email address...\n");
											}
										}
										System.out.println(adminService.updateHotelEmail(strHotelId,hotelEmail));
										break;
									case "6":
										updateHotelChoice='n';
										break;
									default:
										System.out.println("Invalid Selection...\n");	
										break;
									}
									break;
								}
								break;
							case "4":
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Hotel ID : ");
									strHotelId = sc.nextLine();
									isValidInput=adminValidate.isValidNumericInput(strHotelId);
									if(strHotelId.length()!=3 || !isValidInput)
									{
										System.out.println("Hotel ID can only be numeric 3 digit value...\n");
										isValidInput=false;
									}
								}
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Room Number");
									roomNo=sc.nextLine();
									isValidInput=adminValidate.isValidRoomNumber(roomNo);
									if(!isValidInput)
									{
										System.out.println("Room Number can only contain Alphabets & Digits...\n");
									}
								}
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Room Type (Ac / NonAc) : ");
									roomType = sc.nextLine();
									if(roomType.equals("Ac") || roomType.equals("NonAc"))
									{
										isValidInput=true;
										
									}
									else
									{
										System.out.println("Please Enter a Valid Room Type...(Ac / NonAc)\n");
									}
								}
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Rate per night : ");
									strPerNightRate = sc.nextLine();
									isValidInput=adminValidate.isValidAmount(strPerNightRate);
									if(!isValidInput)
									{
										System.out.println("Please Enter a Numerical value...\n");
									}
								}
								System.out.println(adminService.addRoom(strHotelId,roomNo,roomType,strPerNightRate));
								break;
								
							
							case "5":
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Room ID : ");
									strRoomId = sc.nextLine();
									isValidInput=adminValidate.isValidNumericInput(strRoomId);
									if(strRoomId.length()!=4 || !isValidInput)
									{
										System.out.println("Hotel ID can only be numeric 3 digit value...\n");
										isValidInput=false;
									}
								}
								System.out.println(adminService.delRoom(strRoomId));
								break;
								
							case "6":
								String updateRoomOption;
								char updateRoomChoice='y';
								while(updateRoomChoice=='y')
								{
									isValidInput=false;
									while(!isValidInput)
									{
										System.out.println("Enter Room ID: ");
										strRoomId=sc.nextLine();
										isValidInput=adminValidate.isValidNumericInput(strRoomId);
										if(strRoomId.length()!=4 || !isValidInput)
										{
											System.out.println("Room ID can only be numeric 4 digit value...\n");
											isValidInput=false;
										}
									}
									
									System.out.println("Select Field to update\n"
												+ "1. Update Room Type\n"
												+ "2. Update Room Tarrif\n"
												+ "3. Update Room Availability\n"
												+ "Select Option: ");
									updateRoomOption=sc.nextLine();
									switch(updateRoomOption)
									{
									case "1":
										isValidInput=false;
										while(!isValidInput)
										{
											System.out.println("Enter Room Type (Ac / NonAc) : ");
											roomType = sc.nextLine();
											if(roomType.equals("Ac") || roomType.equals("NonAc"))
											{
												isValidInput=true;
												
											}
											else
											{
												System.out.println("Please Enter a Valid Room Type...(Ac / NonAc)\n");
											}
										}
										System.out.println(adminService.updateRoomType(strRoomId,roomType));
										updateRoomChoice='n';
										break;
									case "2":
										isValidInput=false;
										while(!isValidInput)
										{
											System.out.println("Enter New Tarrif : ");
											strPerNightRate = sc.nextLine();
											isValidInput=adminValidate.isValidAmount(strPerNightRate);
											if(!isValidInput)
											{
												System.out.println("Please Enter a Numerical value...\n");
											}
										}
										System.out.println(adminService.updateRoomPerNightRate(strRoomId,strPerNightRate));
										updateRoomChoice='n';
										break;
									case "3":
										isValidInput=false;
										while(!isValidInput)
										{
											System.out.println("Enter Room Availabilty ( 1/0 ): ");
											strAvailability=sc.nextLine();
											isValidInput=(strAvailability.equals("1") || strAvailability.equals("0"));
											if(!isValidInput)
											{
												System.out.println("Invalid Choice...Please Choose: \n"
														+ "1: Available"
														+ "0: Unavilable");
											}
										}
										System.out.println(adminService.updateRoomAvailability(strRoomId,strAvailability));
										updateRoomChoice='n';
										break;
									
									default:
										System.out.println("Invalid Selection...\n");	
										break;
									}
									break;
								}
								break;
							case "7":
								if(adminService.viewListOfHotels().isEmpty())
								{
									System.out.println("NO HOTELS FOUND!!..\n");
								}
								else
								{
									System.out.println("***List of Hotels***\n"+adminService.viewListOfHotels());
								}
								
								break;
								
							case "8":
								if(adminService.viewListOfCustomers().isEmpty())
								{
									System.out.println("NO CUSTOMERS FOUND!!..\n");
								}
								else
								{
									System.out.println("***List of Customers***\n"+adminService.viewListOfCustomers());
								}
								break;
							
							case "9":
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Hotel ID : ");
									strHotelId = sc.nextLine();
									isValidInput=adminValidate.isValidNumericInput(strHotelId);
									if(strHotelId.length()!=3 || !isValidInput)
									{
										System.out.println("Hotel ID can only be numeric 3 digit value...\n");
										isValidInput=false;
									}
								}
								if(adminService.viewBookingsByHotel(strHotelId).isEmpty())
								{
									System.out.println("No bookings found for given Hotel ID "+strHotelId);
								}
								else
								{
									System.out.println("Bookings for Hotel ID: "+strHotelId);
									System.out.println(adminService.viewBookingsByHotel(strHotelId));
								}
								break;
							case "10":
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Date (yyyy-mm-dd) : ");
									strDate = sc.nextLine();
									isValidInput=adminValidate.isValidDate(strDate);
									if(!isValidInput)
									{
										System.out.println("Invalid Date. Check Input Format!!..\n");
									}
								}
								if(adminService.viewBookingsByDate(strDate).isEmpty())
								{
									System.out.println("No Bookings found for given Date "+strDate+"\n");
								}
								else
								{
									System.out.println("Bookings for Date "+strDate);
									System.out.println(adminService.viewBookingsByDate(strDate)+"\n");
								}
								break;
								
							case "11":
								adminChoice='n';
								adminLoginChoice='n';
								break;
							case "12":
								adminChoice='n';
								adminLoginChoice='n';
								mainChoice='n';
								System.out.println("Thank you for using HBMS");
								break;
							default :
								System.out.println("\nInvalid Selection!..Select Again\n");
								break;
						}
					}
				}
				else
				{
					System.out.println("Invalid Login Credentials!..\n");
					System.out.println("\nPress 0 to Go back to home page"
							+ "\nPress any other digit to try again..."
							+ "\n\nSelect option");
					int tryLogin = sc.nextInt();
					sc.nextLine();
					if(tryLogin==0)
					{
						adminLoginChoice='n';
					}
				}
				}
				break;
			case "4":
				System.out.println("Registeration page coming soon...");
				break;
			case "5":
				System.out.println("Thank you for using HBMS!!");
				mainChoice='n';
				break;
			default:
				System.out.println("Invalid Selection!! Select Again\n");
				break;
			}
		}
		
	}

}
