package com.cg.hbms.service;

public interface Validation {

	public boolean isValidAlphanumericInput(String input);
	public boolean isValidAlphabeticInput(String input);
	public boolean isValidNumericInput(String input);
	public boolean isValidAmount(String input);
	public boolean isValidRating(String input);
	public boolean isValidEmailId(String input);
	public boolean isValidRoomNumber(String input);
	public boolean isValidDate(String input);
}
